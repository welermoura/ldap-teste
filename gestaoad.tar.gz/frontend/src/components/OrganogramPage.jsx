import React, { useEffect, useState, useMemo, createContext, useContext, useRef } from 'react';
import {
    ZoomIn,
    ZoomOut,
    RotateCcw,
    UserCircle,
    ChevronDown,
    Network,
    AlertTriangle,
    Loader2,
    LocateFixed,
    CheckCircle2,
    Clock,
    XCircle,
    Mail,
    Phone,
    MapPin,
    ChevronRight,
    ChevronsDown,
    ChevronsUp,
    Building2,
    Users,
    X,
    MessageSquare,
    Target,
    FilterX
} from 'lucide-react';
import OrganogramSearch from './OrganogramSearch';

// --- Context ---
const OrganogramContext = createContext({
    hoveredNodeId: null,
    setHoveredNodeId: () => {},
    focusedNodeId: null,
    setFocusedNodeId: () => {},
    ancestorIds: new Set(),
    selectedProfile: null,
    setSelectedProfile: () => {},
    isolatedNodeId: null,
    setIsolatedNodeId: () => {},
});

// --- Utility Functions ---

const NODE_COLORS = [
    '#059669', // Emerald
    '#d97706', // Amber
    '#2563eb', // Blue
    '#db2777', // Pink
    '#7c3aed', // Violet
    '#ea580c', // Orange
    '#0891b2', // Cyan
    '#4f46e5', // Indigo
    '#dc2626', // Red
    '#65a30d', // Lime
];

const getNodeColor = (index) => {
    return NODE_COLORS[index % NODE_COLORS.length];
};

const getInitials = (name) => {
    if (!name) return '';
    const names = name.split(' ');
    if (names.length >= 2) return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    return name[0].toUpperCase();
};

const filterTreeForIsolation = (nodes, targetId) => {
    if (!nodes || !targetId) return nodes;
    
    const result = [];
    for (const node of nodes) {
        if (node.distinguishedName === targetId) {
            // Se for o nó alvo, retorna ele com todos os filhos originais
            result.push({ ...node });
            continue;
        }
        
        if (node.children && node.children.length > 0) {
            const filteredChildren = filterTreeForIsolation(node.children, targetId);
            if (filteredChildren.length > 0) {
                // Se o alvo está em algum dos filhos, mantém este ancestral
                // mas apenas com o caminho que leva ao alvo
                result.push({ ...node, children: filteredChildren });
            }
        }
    }
    return result;
};

// --- Components ---

const isAggregatedGroup = (nodes) => {
    const GRID_THRESHOLD = 3;
    const leafNodes = nodes.filter(n => !n.children || n.children.length === 0);
    return nodes.length > GRID_THRESHOLD && leafNodes.length > 0;
};

const TreeConnectors = ({ data, expandedNodes, hoveredNodeId, focusedNodeId, zoom }) => {
    const [paths, setPaths] = useState({ staticPaths: [], activePaths: [] });

    useEffect(() => {
        const updatePaths = () => {
            const staticPathsList = [];
            const activePathsList = [];
            const activeId = hoveredNodeId || focusedNodeId;

            // 1. Identify Aggregated Nodes
            // Map of DN -> Parent DN
            const parentMap = new Map();
            const aggregatedNodeSet = new Set();

            const traverse = (nodes, parentId = null) => {
                nodes.forEach(node => {
                    if (parentId) parentMap.set(node.distinguishedName, parentId);

                    if (node.children && node.children.length > 0) {
                         traverse(node.children, node.distinguishedName);
                    }
                });

                // Mimic aggregation logic from renderTree
                const leafNodes = nodes.filter(n => !n.children || n.children.length === 0);
                // The aggregation logic applies to the *group of children* of a parent.
                // The `nodes` array passed here is exactly that group (children of parentId).
                const GRID_THRESHOLD = 3;
                if (nodes.length > GRID_THRESHOLD && leafNodes.length > 0) {
                     leafNodes.forEach(n => aggregatedNodeSet.add(n.distinguishedName));
                }
            };

            // Traverse from Root's children?
            // Root is usually single.
            // But we need to handle the whole tree structure.
            // Data is [Root].
            if (data.length > 0) {
                // Initialize map for Root
                parentMap.set(data[0].distinguishedName, null);
                if (data[0].children) {
                    traverse(data[0].children, data[0].distinguishedName);
                }
            }

            // 2. Build Set of "Active" Connections (Ancestor Chain)
            const activePairs = new Set();
            if (activeId) {
                let curr = activeId;
                while(curr) {
                    activePairs.add(curr);
                    curr = parentMap.get(curr);
                }
            }

            // 3. Generate Paths for ALL visible nodes
            const processedGroups = new Set(); // Track processed aggregate groups to avoid drawing multiple lines

            const processNode = (node, parentId) => {
                if (!node) return;
                const currentId = node.distinguishedName;

                // If I have a parent, draw line Parent -> Me
                if (parentId) {
                    const isAggregated = aggregatedNodeSet.has(currentId);

                    let childEl;
                    let shouldProcess = true;

                    if (isAggregated) {
                        const aggId = `aggregate-${parentId}`;
                        // If we already processed this aggregate group for this parent, skip
                        if (processedGroups.has(aggId)) {
                            shouldProcess = false;
                        } else {
                            // Target the BOX itself
                            childEl = document.getElementById(aggId);
                            processedGroups.add(aggId);
                        }
                    } else {
                        childEl = document.getElementById(currentId);
                    }

                    const parentEl = document.getElementById(parentId);

                    if (shouldProcess && childEl && parentEl) {
                        const childRect = childEl.getBoundingClientRect();
                        const parentRect = parentEl.getBoundingClientRect();

                        const startX = childRect.left + childRect.width / 2;
                        let startY = childRect.top;

                        // If targeting an aggregate box, we want to hit the very top edge, or slightly inside?
                        // Visual tweak: if isAggregated, startY is the top of the box.

                        const endX = parentRect.left + parentRect.width / 2;
                        const endY = parentRect.bottom;

                        const midY = (startY + endY) / 2;

                        // Ensure the line touches the box exactly
                        const d = `M ${startX} ${startY} V ${midY} H ${endX} V ${endY}`;

                        let isActive = false;
                        if (isAggregated) {
                            // Active if ANY aggregated child of this parent is in activePairs
                            // Check if activeId is a child of this parent AND is aggregated
                            if (activeId && parentMap.get(activeId) === parentId && aggregatedNodeSet.has(activeId)) {
                                isActive = true;
                            }
                        } else {
                            isActive = activePairs.has(currentId);
                        }

                        const key = isAggregated ? `agg-${parentId}` : currentId;
                        const pathObj = { d, key, isActive };

                        if (isActive) {
                            activePathsList.push(pathObj);
                        } else {
                            staticPathsList.push(pathObj);
                        }
                    }
                }

                // Recurse if expanded
                // Note: If aggregated, `renderTree` might treat them as hidden/inside box?
                // But `expandedNodes` usually tracks the PARENT being expanded.
                // The nodes inside the aggregate box are logically leaves.
                // We should only recurse if node has children. Leaves don't.
                if (expandedNodes.has(currentId) && node.children) {
                    node.children.forEach(child => processNode(child, currentId));
                }
            };

            data.forEach(root => processNode(root, null));

            // We handled deduplication via `processedGroups` but let's be safe
            setPaths({ staticPaths: staticPathsList, activePaths: activePathsList });
        };

        const loop = () => {
            updatePaths();
            requestAnimationFrame(loop);
        };
        const handle = requestAnimationFrame(loop);
        return () => cancelAnimationFrame(handle);

    }, [data, expandedNodes, hoveredNodeId, focusedNodeId, zoom]);

    return (
        <svg
            style={{
                position: 'fixed',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                pointerEvents: 'none',
                zIndex: 1, // Base level for connectors
            }}
        >
            {/* Static Gray Paths */}
            {paths.staticPaths.map(p => (
                <path
                    key={p.key}
                    d={p.d}
                    stroke="#cbd5e1"
                    strokeWidth="2"
                    fill="none"
                    strokeLinecap="round"
                />
            ))}

            {/* Active Blue Paths (Overlay) */}
            {paths.activePaths.map(p => (
                <path
                    key={p.key}
                    d={p.d}
                    stroke="#3b82f6"
                    strokeWidth="3"
                    fill="none"
                    strokeLinecap="round"
                    style={{
                        filter: 'drop-shadow(0 0 4px rgba(59, 130, 246, 0.5))',
                        zIndex: 40 // Higher visual priority
                    }}
                />
            ))}
        </svg>
    );
};

const AggregateGroup = ({ nodes, parentName, assignedColor, parentId }) => {
    const [showAll, setShowAll] = useState(false);
    const { focusedNodeId, hoveredNodeId } = useContext(OrganogramContext);

    // Check if the group is active (contains focused or hovered node)
    const isActive = useMemo(() => {
        return nodes.some(n =>
            n.distinguishedName === focusedNodeId ||
            n.distinguishedName === hoveredNodeId
        );
    }, [nodes, focusedNodeId, hoveredNodeId]);

    // Automatically expand if the focused node is inside this group
    useEffect(() => {
        if (focusedNodeId) {
            const isFocusedInGroup = nodes.some(node => node.distinguishedName === focusedNodeId);
            if (isFocusedInGroup) {
                setShowAll(true);
            }
        }
    }, [focusedNodeId, nodes]);

    const initialLimit = 12;
    const displayNodes = showAll ? nodes : nodes.slice(0, initialLimit);
    const hasMore = nodes.length > initialLimit;

    return (
        <div
            className="aggregate-box-wrapper"
        >
            {/* Single vertical connector from parent */}
            <div className={`connector-vertical-aggregate ${isActive ? 'active' : ''}`}></div>

            <div
                className={`aggregate-box ${isActive ? 'box-active' : ''}`}
                id={`aggregate-${parentId}`}
            >
                <div className="aggregate-header">
                    <h5>Pessoas que respondem a {parentName} ({nodes.length})</h5>
                </div>
                <div className="aggregate-grid">
                    {displayNodes.map((node) => (
                        <NodeCard
                            key={node.distinguishedName}
                            node={node}
                            isGridItem={true}
                            hasChildren={false}
                            isExpanded={false}
                            toggleNode={() => {}}
                            isMatch={false}
                            parentId={null}
                            assignedColor={assignedColor}
                        />
                    ))}
                </div>
                {hasMore && (
                    <div className="aggregate-footer">
                        <button className="btn-view-more" onClick={() => setShowAll(!showAll)}>
                            {showAll ? 'Visualizar menos' : 'Visualizar mais'}
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

const NodeCard = ({ node, isExpanded, toggleNode, hasChildren, isMatch, parentId, isGridItem, assignedColor, parentName }) => {
    const { hoveredNodeId, setHoveredNodeId, focusedNodeId, setFocusedNodeId, ancestorIds, setSelectedProfile } = useContext(OrganogramContext);

    // Use the assigned color from parent, or default to Slate-500 if root/undefined
    const nodeColor = assignedColor || '#64748b';

    const nodeId = node.distinguishedName;

    // States calculation
    const isHovered = hoveredNodeId === nodeId;
    const isFocused = focusedNodeId === nodeId;
    const isDirectSubordinate = hoveredNodeId === parentId && hoveredNodeId !== null;
    const isAncestor = ancestorIds.has(nodeId);

    // Logic: Dim if someone is focused/hovered, but this node is NOT involved
    // Involved = Hovered OR Focused OR Direct Subordinate OR Ancestor
    const isInteracting = hoveredNodeId !== null || focusedNodeId !== null;
    const isRelevant = isHovered || isFocused || isDirectSubordinate || isAncestor;
    const isDimmed = isInteracting && !isRelevant;

    const isExecutive = node.title && (
        node.title.toLowerCase().includes('presidente') ||
        node.title.toLowerCase().includes('ceo') ||
        node.title.toLowerCase().includes('diretor')
    );

    const handleMouseEnter = (e) => {
        e.stopPropagation();
        setHoveredNodeId(nodeId);
    };

    const handleMouseLeave = () => {
        setHoveredNodeId(null);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            setFocusedNodeId(nodeId);
            setSelectedProfile({ ...node, assignedColor: nodeColor, parentName });
            if (hasChildren) toggleNode();
        }
    };

    return (
        <div
            id={nodeId}
            className={`
                org-card
                ${isGridItem ? 'card-grid' : ''}
                ${isMatch ? 'highlight' : ''}
                ${isExecutive ? 'executive' : ''}
                ${isHovered ? 'state-active' : ''}
                ${isFocused ? 'state-focused' : ''}
                ${isDirectSubordinate ? 'state-subordinate' : ''}
                ${isAncestor ? 'state-ancestor' : ''}
                ${isDimmed ? 'state-dimmed' : ''}
                ${node.isDisabled ? 'state-disabled' : ''}
            `}
            onClick={(e) => {
                e.stopPropagation();
                setFocusedNodeId(nodeId);
                setSelectedProfile({ ...node, assignedColor: nodeColor, parentName });
                if (hasChildren) toggleNode();
            }}
            onKeyDown={handleKeyDown}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            style={{
                '--dept-color': nodeColor,
            }}
            role="button"
            aria-expanded={isExpanded}
            aria-label={`${node.name}, ${node.title}`}
            tabIndex={0}
        >
            <div className="card-accent"></div>

            <div className="card-body">
                <div className="card-header">
                    <div className="avatar" style={{
                        background: isExecutive ? 'linear-gradient(135deg, #1e293b, #0f172a)' : `linear-gradient(135deg, ${nodeColor}25, ${nodeColor}05)`,
                        color: isExecutive ? '#fff' : nodeColor,
                        border: `1px solid ${isExecutive ? '#334155' : `${nodeColor}30`}`
                    }}>
                        {getInitials(node.name)}
                    </div>
                    <div className="info">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <h6 className="name" title={node.name}>{node.name}</h6>
                            {node.isDisabled && (
                                <span title="Afastado / Bloqueado" style={{ color: '#ef4444' }}>
                                    <XCircle size={14} />
                                </span>
                            )}
                        </div>
                        <p className="role" title={node.title}>{node.title || 'Cargo não definido'}</p>
                    </div>
                </div>

                {node.department && (
                    <div className="card-footer">
                        <span className="dept-badge" style={{
                             backgroundColor: `${nodeColor}08`,
                             color: nodeColor,
                             borderColor: `${nodeColor}20`
                        }}>
                            {node.department}
                        </span>
                    </div>
                )}
            </div>

            {hasChildren && (
                <div 
                    className={`toggle-btn ${isExpanded ? 'expanded' : ''}`}
                    onClick={(e) => {
                        e.stopPropagation();
                        toggleNode();
                    }}
                >
                    <ChevronDown size={14} className="icon-chevron" />
                </div>
            )}
        </div>
    );
};

const ProfileOffcanvas = () => {
    const { selectedProfile, setSelectedProfile, isolatedNodeId, setIsolatedNodeId } = useContext(OrganogramContext);

    if (!selectedProfile) return null;

    const node = selectedProfile;
    const isExecutive = node.title && (node.title.toLowerCase().includes('presidente') || node.title.toLowerCase().includes('diretor'));
    const nodeColor = selectedProfile.assignedColor || '#64748b';

    return (
        <>
            {/* Backdrop */}
            <div 
                style={{
                    position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
                    backgroundColor: 'rgba(15, 23, 42, 0.4)', backdropFilter: 'blur(4px)',
                    zIndex: 999, transition: 'opacity 0.3s'
                }}
                onClick={() => setSelectedProfile(null)}
            />
            {/* Offcanvas Panel */}
            <div className="profile-offcanvas" style={{
                position: 'fixed', top: 0, right: 0, width: '400px', maxWidth: '90vw', height: '100vh',
                background: 'var(--bg-card)', backdropFilter: 'none',
                boxShadow: '-10px 0 25px rgba(0,0,0,0.5)', zIndex: 1000,
                display: 'flex', flexDirection: 'column',
                transform: selectedProfile ? 'translateX(0)' : 'translateX(100%)',
                transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                borderLeft: '1px solid var(--glass-border-color)',
                color: 'var(--text-color)',
                overflowY: 'auto'
            }}>
                <button 
                    onClick={() => setSelectedProfile(null)}
                    style={{
                        position: 'absolute', top: '16px', right: '16px',
                        background: 'transparent', border: 'none', color: 'var(--text-muted-color)',
                        cursor: 'pointer', padding: '4px', borderRadius: '50%',
                        display: 'flex', alignItems: 'center', justifyContent: 'center'
                    }}
                >
                    <X size={24} />
                </button>

                <div style={{ padding: '32px 24px', textAlign: 'center', borderBottom: '1px solid var(--glass-border-color)' }}>
                    <div style={{
                        width: '96px', height: '96px', borderRadius: '50%', margin: '0 auto 16px',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', fontWeight: 'bold',
                        background: isExecutive ? 'linear-gradient(135deg, #1e293b, #0f172a)' : `linear-gradient(135deg, ${nodeColor}30, ${nodeColor}10)`,
                        color: isExecutive ? '#fff' : nodeColor,
                        border: `2px solid ${isExecutive ? '#334155' : `${nodeColor}40`}`,
                        boxShadow: `0 8px 16px ${isExecutive ? 'rgba(0,0,0,0.2)' : `${nodeColor}20`}`
                    }}>
                        {getInitials(node.name)}
                    </div>
                    <h3 style={{ margin: '0 0 8px 0', fontSize: '1.25rem', fontWeight: '600' }}>{node.name}</h3>
                    <p style={{ margin: 0, color: 'var(--text-muted-color)', fontSize: '0.95rem' }}>{node.title || 'Cargo não definido'}</p>
                    {node.department && (
                        <span style={{ 
                            display: 'inline-block', marginTop: '12px', padding: '4px 12px', borderRadius: '20px', 
                            fontSize: '0.8rem', fontWeight: '500', 
                            backgroundColor: `${nodeColor}15`, color: nodeColor, border: `1px solid ${nodeColor}30`
                        }}>
                            {node.department}
                        </span>
                    )}

                    {node.isDisabled && (
                        <div style={{ 
                            marginTop: '16px', padding: '8px 12px', borderRadius: '8px', 
                            backgroundColor: 'rgba(239, 68, 68, 0.1)', color: '#ef4444', 
                            border: '1px solid rgba(239, 68, 68, 0.2)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                            fontSize: '0.9rem', fontWeight: '500'
                        }}>
                            <AlertTriangle size={16} />
                            Status: Bloqueado / Afastado
                        </div>
                    )}
                </div>

                <div style={{ padding: '24px', flex: 1 }}>
                    <h4 style={{ fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-muted-color)', marginBottom: '16px' }}>Contato</h4>
                    
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        {node.mail && (
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                <div style={{ width: '36px', height: '36px', borderRadius: '8px', background: 'rgba(59, 130, 246, 0.1)', color: '#3b82f6', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <Mail size={18} />
                                </div>
                                <div style={{ flex: 1, overflow: 'hidden' }}>
                                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted-color)' }}>Email</div>
                                    <a href={`mailto:${node.mail}`} style={{ color: 'var(--text-color)', textDecoration: 'none', fontSize: '0.95rem', display: 'block', textOverflow: 'ellipsis', overflow: 'hidden' }}>{node.mail}</a>
                                </div>
                            </div>
                        )}
                        
                        {node.telephoneNumber && (
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                <div style={{ width: '36px', height: '36px', borderRadius: '8px', background: 'rgba(16, 185, 129, 0.1)', color: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <Phone size={18} />
                                </div>
                                <div>
                                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted-color)' }}>Ramal / Telefone</div>
                                    <a href={`tel:${node.telephoneNumber}`} style={{ color: 'var(--text-color)', textDecoration: 'none', fontSize: '0.95rem' }}>{node.telephoneNumber}</a>
                                </div>
                            </div>
                        )}

                        {node.office && (
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                <div style={{ width: '36px', height: '36px', borderRadius: '8px', background: 'rgba(245, 158, 11, 0.1)', color: '#f59e0b', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <MapPin size={18} />
                                </div>
                                <div>
                                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted-color)' }}>Escritório</div>
                                    <div style={{ color: 'var(--text-color)', fontSize: '0.95rem' }}>{node.office}</div>
                                </div>
                            </div>
                        )}
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '24px' }}>
                        <a 
                            href={`msteams:/l/chat/0/0?users=${node.mail}`}
                            style={{ 
                                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', 
                                padding: '10px', borderRadius: '8px', 
                                background: '#5b5fc7', color: '#fff', textDecoration: 'none', 
                                fontWeight: '500', fontSize: '0.95rem', transition: 'background 0.2s'
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.background = '#4a4e9e'}
                            onMouseLeave={(e) => e.currentTarget.style.background = '#5b5fc7'}
                        >
                            <MessageSquare size={18} />
                            Chamar no Teams
                        </a>

                        <button 
                            onClick={() => {
                                setIsolatedNodeId(node.distinguishedName);
                                setSelectedProfile(null);
                            }}
                            style={{ 
                                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', 
                                padding: '10px', borderRadius: '8px', 
                                background: 'var(--text-primary)', color: '#fff', border: 'none',
                                fontWeight: '500', fontSize: '0.95rem', cursor: 'pointer', transition: 'opacity 0.2s'
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.opacity = '0.9'}
                            onMouseLeave={(e) => e.currentTarget.style.opacity = '1'}
                        >
                            <Target size={18} />
                            Focar nesta Estrutura
                        </button>
                    </div>

                    <hr style={{ borderColor: 'var(--glass-border-color)', margin: '24px 0', opacity: 0.5 }} />

                    <h4 style={{ fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-muted-color)', marginBottom: '16px' }}>Hierarquia</h4>
                    
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        {node.parentName && (
                            <div>
                                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted-color)', marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                                    <Building2 size={14} /> Responde a
                                </div>
                                <div style={{ background: 'var(--input-background)', border: '1px solid var(--input-border-color)', padding: '10px 14px', borderRadius: '8px', fontSize: '0.95rem' }}>
                                    {node.parentName}
                                </div>
                            </div>
                        )}

                        {node.children && node.children.length > 0 && (
                            <div>
                                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted-color)', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                                    <Users size={14} /> Equipe Direta ({node.children.length})
                                </div>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                    {node.children.map(child => (
                                        <div key={child.distinguishedName} style={{ background: 'var(--input-background)', border: '1px solid var(--input-border-color)', padding: '10px 14px', borderRadius: '8px' }}>
                                            <div style={{ fontWeight: '500', fontSize: '0.9rem', color: 'var(--text-color)' }}>{child.name}</div>
                                            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted-color)' }}>{child.title || 'Cargo não definido'}</div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                        {(!node.children || node.children.length === 0) && (
                            <div style={{ fontSize: '0.9rem', color: 'var(--text-muted-color)', fontStyle: 'italic' }}>
                                Nenhum subordinado direto.
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
};

const OrganogramPage = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [zoom, setZoom] = useState(1);
    const [expandedNodes, setExpandedNodes] = useState(new Set());
    const [hoveredNodeId, setHoveredNodeId] = useState(null);
    const [focusedNodeId, setFocusedNodeId] = useState(null);
    const [ancestorIds, setAncestorIds] = useState(new Set());
    const [selectedProfile, setSelectedProfile] = useState(null);
    const [isolatedNodeId, setIsolatedNodeId] = useState(null);

    // Filtered Data for Isolation Mode
    const filteredData = useMemo(() => {
        if (!isolatedNodeId) return data;
        return filterTreeForIsolation(data, isolatedNodeId);
    }, [data, isolatedNodeId]);

    // Drag-to-pan state
    const canvasRef = useRef(null);
    const [isDragging, setIsDragging] = useState(false);
    const [startPos, setStartPos] = useState({ x: 0, y: 0 });
    const [scrollPos, setScrollPos] = useState({ left: 0, top: 0 });

    useEffect(() => {
        fetch('/api/public/organogram_data')
            .then(res => {
                if (!res.ok) throw new Error('Falha ao carregar dados');
                return res.json();
            })
            .then(data => {
                const validData = Array.isArray(data) ? data : [];
                setData(validData);

                // Expandir raízes inicialmente
                const initialExpanded = new Set();
                validData.forEach((node, index) => {
                    const key = node.distinguishedName || index;
                    initialExpanded.add(key);
                });
                setExpandedNodes(initialExpanded);

                setLoading(false);
            })
            .catch(err => {
                setError(err.message);
                setLoading(false);
            });
    }, []);

    // Helper: Find Path
    const findPathToNode = (nodes, targetId, path = []) => {
        for (const node of nodes) {
            const currentId = node.distinguishedName;
            if (currentId === targetId) {
                return [...path, currentId]; // Include target for full highlighting
            }
            if (node.children) {
                const result = findPathToNode(node.children, targetId, [...path, currentId]);
                if (result) return result;
            }
        }
        return null;
    };

    // Update Ancestors on Hover/Focus
    useEffect(() => {
        const targetId = hoveredNodeId || focusedNodeId;
        if (targetId) {
            const path = findPathToNode(filteredData, targetId);
            if (path) {
                setAncestorIds(new Set(path));
            } else {
                setAncestorIds(new Set());
            }
        } else {
            setAncestorIds(new Set());
        }
    }, [hoveredNodeId, focusedNodeId, data]);

    // Zoom on Wheel
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const handleWheel = (e) => {
            if (e.ctrlKey || e.metaKey || true) { // Default behavior for canvas zoom
                e.preventDefault();
                const delta = -e.deltaY * 0.001;
                setZoom(prev => Math.min(Math.max(prev + delta, 0.4), 2));
            }
        };

        canvas.addEventListener('wheel', handleWheel, { passive: false });
        return () => canvas.removeEventListener('wheel', handleWheel);
    }, []);

    // Scroll effect for focused node
    useEffect(() => {
        if (focusedNodeId) {
            setTimeout(() => {
                const element = document.getElementById(focusedNodeId);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
                }
            }, 100);

            const timer = setTimeout(() => {
                setFocusedNodeId(null);
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [focusedNodeId]);

    // Drag handlers
    const handleMouseDown = (e) => {
        if (!canvasRef.current) return;
        setIsDragging(true);
        setStartPos({ x: e.pageX, y: e.pageY });
        setScrollPos({
            left: canvasRef.current.scrollLeft,
            top: canvasRef.current.scrollTop
        });
    };

    const handleMouseMove = (e) => {
        if (!isDragging || !canvasRef.current) return;
        e.preventDefault();
        const x = e.pageX - startPos.x;
        const y = e.pageY - startPos.y;
        canvasRef.current.scrollLeft = scrollPos.left - x;
        canvasRef.current.scrollTop = scrollPos.top - y;
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };

    const toggleNode = (key) => {
        setExpandedNodes(prev => {
            const newSet = new Set(prev);
            if (newSet.has(key)) {
                newSet.delete(key);
            } else {
                newSet.add(key);
            }
            return newSet;
        });
    };

    const handleExpandAll = () => {
        const allIds = new Set();
        const traverse = (nodes) => {
            if (!nodes) return;
            nodes.forEach(node => {
                allIds.add(node.distinguishedName);
                if (node.children) traverse(node.children);
            });
        };
        traverse(data);
        setExpandedNodes(allIds);
    };

    const handleCollapseAll = () => {
        const rootIds = new Set();
        data.forEach(node => rootIds.add(node.distinguishedName));
        setExpandedNodes(rootIds);
    };

    const handleSelectNode = (nodeId) => {
        const path = findPathToNode(data, nodeId);
        if (path) {
            setExpandedNodes(prev => new Set([...prev, ...path]));
        }
        setFocusedNodeId(nodeId);
    };

    const handleZoomIn = () => setZoom(prev => Math.min(prev + 0.1, 2));
    const handleZoomOut = () => setZoom(prev => Math.max(prev - 0.1, 0.4));
    const handleResetZoom = () => setZoom(1);

    const handleCenterFocused = () => {
        if (focusedNodeId) {
            const element = document.getElementById(focusedNodeId);
            if (element) {
                element.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
            }
        }
    };

    // Recursively render tree
    const renderTree = (nodes, parentNode = null, parentColor = null, depth = 0) => {
        if (!nodes || !Array.isArray(nodes) || nodes.length === 0) return null;

        // --- Split Children Logic ---

        const branchNodes = [];
        const leafNodes = [];

        nodes.forEach(node => {
            if (node.children && node.children.length > 0) {
                branchNodes.push(node);
            } else {
                leafNodes.push(node);
            }
        });

        // Use shared logic for aggregation check
        // We can re-use the isAggregatedGroup function or logic here.
        // Logic: if total nodes > threshold AND we have leaves.
        const GRID_THRESHOLD = 3;
        const shouldUseAggregation = nodes.length > GRID_THRESHOLD && leafNodes.length > 0;

        let displayNodes = [];

        if (shouldUseAggregation) {
            branchNodes.sort((a, b) => a.name.localeCompare(b.name));
            displayNodes = [...branchNodes];
            if (leafNodes.length > 0) {
                displayNodes.push({
                    isAggregate: true,
                    nodes: leafNodes,
                    distinguishedName: `aggregate-${parentNode ? parentNode.distinguishedName : 'root'}`
                });
            }
        } else {
            displayNodes = nodes;
        }

        return (
            <ul
                className="org-tree"
                style={{
                    display: 'flex',
                    justifyContent: 'center',
                }}
            >
                {displayNodes.map((item, index) => {
                    if (item.isAggregate) {
                        const key = item.distinguishedName;
                        const aggColor = parentColor || getNodeColor(index + depth);

                        return (
                            <li key={key} className="org-leaf">
                                <div className="connector-vertical"></div>
                                <AggregateGroup
                                    nodes={item.nodes}
                                    parentName={parentNode ? parentNode.name : 'Unknown'}
                                    assignedColor={aggColor}
                                    parentId={parentNode ? parentNode.distinguishedName : 'root'}
                                />
                            </li>
                        );
                    }

                    const node = item;
                    const key = node.distinguishedName || index;
                    const hasChildren = node.children && node.children.length > 0;
                    const isExpanded = expandedNodes.has(key);
                    const myColor = hasChildren ? getNodeColor(index + depth) : (parentColor || getNodeColor(index + depth));

                    return (
                        <li key={key} className="org-leaf">
                            <div className="connector-vertical"></div>

                            <NodeCard
                                node={node}
                                isExpanded={isExpanded}
                                toggleNode={() => toggleNode(key)}
                                hasChildren={hasChildren}
                                isMatch={false}
                                parentId={parentNode ? parentNode.distinguishedName : null}
                                assignedColor={myColor}
                                parentName={parentNode ? parentNode.name : null}
                            />
                            {hasChildren && isExpanded && renderTree(node.children, node, myColor, depth + 1)}
                        </li>
                    );
                })}
            </ul>
        );
    };

    if (loading) return (
        <div className="loading-container">
            <Loader2 className="spinner" size={40} />
            <p>Carregando estrutura...</p>
        </div>
    );

    if (error) return (
        <div className="error-container">
            <AlertTriangle size={48} className="text-red-500" />
            <p>Erro ao carregar: {error}</p>
        </div>
    );

    return (
        <OrganogramContext.Provider value={{ 
            hoveredNodeId, setHoveredNodeId, 
            focusedNodeId, setFocusedNodeId, 
            ancestorIds, 
            selectedProfile, setSelectedProfile,
            isolatedNodeId, setIsolatedNodeId
        }}>
            <div className="organogram-page">
                <TreeConnectors
                    data={filteredData}
                    expandedNodes={expandedNodes}
                    hoveredNodeId={hoveredNodeId}
                    focusedNodeId={focusedNodeId}
                    zoom={zoom}
                />
                <header className="page-header">
                    <div className="brand">
                        <div className="brand-icon" style={{
                            background: window.ORGANOGRAM_CONFIG?.logo ? 'transparent' : null,
                            padding: window.ORGANOGRAM_CONFIG?.logo ? 0 : null,
                            overflow: 'hidden'
                        }}>
                            {window.ORGANOGRAM_CONFIG?.logo ? (
                                <img
                                    src={`/static/uploads/${window.ORGANOGRAM_CONFIG.logo}`}
                                    alt="Logo"
                                    style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                                />
                            ) : (
                                <Network size={20} />
                            )}
                        </div>
                        <div className="brand-text">
                            <h2>Organograma</h2>
                            <span>{window.ORGANOGRAM_CONFIG?.subtitle || 'Corporativo'}</span>
                        </div>
                    </div>

                    <div className="actions">
                        {isolatedNodeId && (
                            <button 
                                onClick={() => setIsolatedNodeId(null)}
                                style={{
                                    display: 'flex', alignItems: 'center', gap: '8px',
                                    padding: '8px 16px', borderRadius: '8px',
                                    background: '#fee2e2', color: '#dc2626', border: '1px solid #fecaca',
                                    fontWeight: '600', fontSize: '0.85rem', cursor: 'pointer',
                                    transition: 'background 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = '#fecaca'}
                                onMouseLeave={(e) => e.currentTarget.style.background = '#fee2e2'}
                            >
                                <FilterX size={16} />
                                Sair do Modo Foco
                            </button>
                        )}
                        <OrganogramSearch data={data} onSelect={handleSelectNode} />

                        <div className="zoom-controls">
                            <button onClick={handleExpandAll} title="Expandir Tudo"><ChevronsDown size={16} /></button>
                            <button onClick={handleCollapseAll} title="Recolher Tudo"><ChevronsUp size={16} /></button>
                            <div className="separator"></div>
                            <button onClick={handleCenterFocused} disabled={!focusedNodeId} title="Centralizar Seleção" style={{ opacity: focusedNodeId ? 1 : 0.4 }}>
                                <LocateFixed size={16} />
                            </button>
                            <div className="separator"></div>
                            <button onClick={handleZoomOut} title="Reduzir Zoom"><ZoomOut size={16} /></button>
                            <span className="zoom-level">{Math.round(zoom * 100)}%</span>
                            <button onClick={handleZoomIn} title="Aumentar Zoom"><ZoomIn size={16} /></button>
                            <div className="separator"></div>
                            <button onClick={handleResetZoom} title="Resetar"><RotateCcw size={14} /></button>
                        </div>
                    </div>
                </header>

                <main
                    className={`canvas ${isDragging ? 'grabbing' : ''}`}
                    ref={canvasRef}
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                >
                    <div
                        className="tree-wrapper"
                        style={{
                            transform: `scale(${zoom})`,
                        }}
                    >
                        {renderTree(filteredData, null)}
                    </div>
                </main>

            <ProfileOffcanvas />

            <style>{`
                    /* --- Fonts & Vars --- */
                    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

                    :root {
                        --bg-page: #f8fafc; /* Slate 50 */
                        --bg-card: #FAFAFB; /* Off-white premium */
                        --text-primary: #1e293b; /* Slate 800 */
                        --text-secondary: #64748b; /* Slate 500 */
                        --border-color: #e2e8f0; /* Slate 200 */
                        --line-color: #cbd5e1; /* Slate 300 */
                        --line-active: #3b82f6; /* Blue 500 */

                        /* Shadows - Premium Depth */
                        --shadow-sm: 0 2px 4px rgba(0,0,0,0.02), 0 1px 2px rgba(0,0,0,0.03);
                        --shadow-md: 0 8px 16px -4px rgba(0,0,0,0.04), 0 4px 8px -2px rgba(0,0,0,0.02);
                        --shadow-hover: 0 20px 30px -8px rgba(0,0,0,0.08), 0 8px 12px -4px rgba(0,0,0,0.03);

                        --ease-out: cubic-bezier(0.25, 0.46, 0.45, 0.94);
                    }

                    * { box-sizing: border-box; }

                    .organogram-page {
                        font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                        background-color: var(--bg-page);
                        height: 100vh;
                        display: flex;
                        flex-direction: column;
                        overflow: hidden;
                        color: var(--text-primary);
                    }

                    /* --- Header --- */
                    .page-header {
                        background: rgba(255, 255, 255, 0.85);
                        backdrop-filter: blur(12px);
                        border-bottom: 1px solid var(--border-color);
                        height: 72px;
                        padding: 0 32px;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        z-index: 50;
                        box-shadow: var(--shadow-sm);
                    }

                    .brand {
                        display: flex;
                        align-items: center;
                        gap: 12px;
                    }
                    .brand-icon {
                        width: 36px;
                        height: 36px;
                        background: var(--text-primary);
                        color: #fff;
                        border-radius: 8px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    .brand-text h2 {
                        margin: 0;
                        font-size: 1rem;
                        font-weight: 700;
                        letter-spacing: -0.02em;
                        line-height: 1.2;
                    }
                    .brand-text span {
                        font-size: 0.75rem;
                        color: var(--text-secondary);
                        font-weight: 500;
                        text-transform: uppercase;
                        letter-spacing: 0.05em;
                    }

                    .actions {
                        display: flex;
                        align-items: center;
                        gap: 24px;
                    }

                    /* Zoom */
                    .zoom-controls {
                        display: flex;
                        align-items: center;
                        background: #fff;
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 4px;
                        box-shadow: var(--shadow-sm);
                    }
                    .zoom-controls button {
                        width: 32px;
                        height: 32px;
                        border: none;
                        background: transparent;
                        border-radius: 6px;
                        color: var(--text-secondary);
                        cursor: pointer;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        transition: all 0.15s;
                    }
                    .zoom-controls button:hover {
                        background: var(--bg-page);
                        color: var(--text-primary);
                    }
                    .zoom-level {
                        font-size: 0.8rem;
                        font-weight: 600;
                        width: 48px;
                        text-align: center;
                        font-variant-numeric: tabular-nums;
                    }
                    .separator {
                        width: 1px;
                        height: 16px;
                        background: var(--border-color);
                        margin: 0 4px;
                    }

                    .btn-login {
                        background: var(--text-primary);
                        color: #fff;
                        text-decoration: none;
                        padding: 10px 16px;
                        border-radius: 8px;
                        font-size: 0.9rem;
                        font-weight: 600;
                        display: flex;
                        align-items: center;
                        gap: 8px;
                        transition: all 0.2s;
                    }
                    .btn-login:hover {
                        background: #334155;
                        transform: translateY(-1px);
                    }

                    /* --- Canvas --- */
                    .canvas {
                        flex: 1;
                        overflow: auto;
                        padding: 80px 40px;
                        cursor: grab;
                        background-image:
                            radial-gradient(#e2e8f0 1px, transparent 1px);
                        background-size: 24px 24px;
                        user-select: none; /* Prevent text selection while dragging */
                    }
                    .canvas:active { cursor: grabbing; }
                    .canvas.grabbing { cursor: grabbing; }

                    .tree-wrapper {
                        display: flex;
                        justify-content: center;
                        width: max-content;
                        min-width: 100%;
                        transform-origin: top center;
                        transition: transform 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
                    }

                    .org-tree {
                        display: flex;
                        justify-content: center;
                        list-style: none;
                        padding: 0;
                        margin: 0;
                        position: relative;
                    }

                    .org-leaf {
                        position: relative;
                        padding: 60px 32px 0 32px;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                    }

                    /* --- Aggregate Box Layout --- */
                    .aggregate-box-wrapper {
                        padding-top: 60px;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        position: relative;
                        width: 100%;
                    }

                    .connector-vertical-aggregate {
                        position: absolute;
                        top: 0;
                        left: 50%;
                        width: 2px;
                        height: 60px;
                        background-color: var(--line-color);
                        transform: translateX(-50%);
                        transition: background-color 0.2s;
                    }
                    .connector-vertical-aggregate.active {
                        background-color: var(--line-active);
                        animation: pulse-line 2s infinite ease-in-out;
                    }

                    .aggregate-box {
                        background: #fff;
                        border: 1px solid var(--border-color);
                        border-radius: 12px;
                        box-shadow: var(--shadow-md);
                        width: 100%;
                        max-width: 900px;
                        padding: 20px;
                        transition: border-color 0.2s, box-shadow 0.2s;
                    }
                    .aggregate-box.box-active {
                        border-color: var(--line-active);
                        box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2), var(--shadow-md);
                    }

                    .aggregate-header h5 {
                        margin: 0 0 16px 0;
                        font-size: 0.95rem;
                        color: var(--text-secondary);
                        font-weight: 500;
                    }

                    .aggregate-grid {
                        display: grid;
                        grid-template-columns: repeat(3, 1fr);
                        gap: 16px;
                    }

                    .aggregate-footer {
                        margin-top: 16px;
                        display: flex;
                        justify-content: center;
                    }

                    .btn-view-more {
                        background: transparent;
                        border: none;
                        color: var(--line-active);
                        font-weight: 600;
                        cursor: pointer;
                        font-size: 0.9rem;
                    }
                    .btn-view-more:hover { text-decoration: underline; }

                    /* Compact User Card */
                    .compact-user-card {
                        display: flex;
                        align-items: center;
                        gap: 12px;
                        padding: 8px;
                        border-radius: 8px;
                        transition: background-color 0.2s;
                    }
                    .compact-user-card:hover {
                        background-color: #f8fafc;
                    }

                    .compact-avatar {
                        width: 36px;
                        height: 36px;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-weight: 600;
                        font-size: 0.85rem;
                        position: relative;
                        flex-shrink: 0;
                    }

                    .status-indicator {
                        position: absolute;
                        bottom: -2px;
                        right: -2px;
                        background: #fff;
                        border-radius: 50%;
                        display: flex;
                        padding: 1px;
                    }

                    .compact-info {
                        min-width: 0;
                    }

                    .compact-name {
                        font-weight: 600;
                        font-size: 0.9rem;
                        color: var(--text-primary);
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                    }

                    .compact-role {
                        font-size: 0.8rem;
                        color: var(--text-secondary);
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                    }

                    /* --- Grid Layout (For large teams > 8) --- */
                    .org-grid-wrapper {
                        display: grid;
                        grid-template-columns: repeat(3, 1fr); /* 3 Columns */
                        gap: 24px;
                        padding-top: 60px; /* Space for parent connector */
                        position: relative;
                        width: 100%;
                        max-width: 1200px;
                    }

                    /* Grid Parent Connector - Vertical Stem */
                    .org-grid-wrapper::before {
                        content: '';
                        position: absolute;
                        top: 0;
                        left: 50%;
                        width: 2px;
                        height: 32px; /* Slight overlap with bus bar */
                        background-color: var(--line-color);
                        transform: translateX(-50%);
                        transition: background-color 0.2s;
                    }

                    /* Grid Horizontal Bus Bar */
                    .org-grid-wrapper::after {
                        content: '';
                        position: absolute;
                        top: 30px; /* Starts where the stem ends */
                        left: 16.66%; /* Starts at the center of the first column (100/3/2 = 16.66) */
                        right: 16.66%; /* Ends at the center of the last column */
                        height: 2px;
                        background-color: var(--line-color);
                    }

                    .org-grid-wrapper.grid-active::before,
                    .org-grid-wrapper.grid-active::after {
                        background-color: var(--line-active);
                        animation: pulse-line 2s infinite ease-in-out;
                    }

                    .grid-item {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        position: relative;
                    }

                    /* Grid Item Connections - Top Row Only */
                     .grid-item:nth-child(-n+3)::before {
                        content: '';
                        position: absolute;
                        top: -32px; /* Slight overlap with bus bar */
                        width: 2px;
                        height: 32px;
                        background-color: var(--line-color);
                        z-index: 0;
                     }

                     /* Grid Horizontal Connector (The 'Bus') */
                     /* We put a pseudo element on the grid items in the first row to connect them?
                        No, that's hard. Better to put a background line on the wrapper. */

                     .grid-item.grid-item-active::before {
                        background-color: var(--line-active);
                        animation: pulse-line 2s infinite ease-in-out;
                     }

                    /* Compact Card for Grid */
                    .card-grid {
                        width: 100%; /* Fill grid cell */
                        max-width: 320px;
                    }

                    /* --- Connectors (Legacy CSS Removed - Now SVG) --- */
                    /* We keep spacing/padding, but remove visual borders */

                    .org-tree::before { display: none; }
                    .org-leaf::before, .org-leaf::after { display: none; }
                    .connector-vertical { display: none; } /* Removed, handled by SVG */
                    .org-leaf > ul::before { display: none; }

                    /* Aggregate Box Connector - also removed, handled by SVG */
                    .connector-vertical-aggregate { display: none; }

                    /* Grid wrapper parent connectors also removed?
                       Wait, Grid layout inside Aggregate box is local.
                       The SVG handles Parent -> Box.
                       The lines INSIDE the box (Grid) are probably fine to keep CSS?
                       Or did we want those SVG too?
                       User asked for "The line passing through the gray line".
                       The user image showed the line OUTSIDE the box.
                       So we only need to replace the Tree Structure lines.
                       The Aggregate Grid lines are internal.
                    */

                    /* --- Card Styles --- */
                    .org-card {
                        width: 280px;
                        background-color: #fff;
                        border: 1px solid var(--border-color);
                        border-radius: 16px;
                        box-shadow: var(--shadow-sm);
                        display: flex;
                        flex-direction: row;
                        transition: all 0.3s var(--ease-out);
                        cursor: pointer;
                        overflow: visible;
                        position: relative;
                    }

                    /* Left Accent Bar */
                    .card-accent {
                        width: 5px;
                        height: 100%;
                        background-color: var(--dept-color);
                        flex-shrink: 0;
                    }

                    .card-body {
                        flex: 1;
                        padding: 14px 16px;
                        display: flex;
                        flex-direction: column;
                        gap: 10px;
                        border-radius: 0 16px 16px 0;
                    }

                    /* Hover State */
                    .org-card.state-active {
                        transform: translateY(-4px) scale(1.02);
                        box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1);
                        z-index: 50;
                        border-color: var(--line-active);
                    }

                    /* Focused State */
                    .org-card.state-focused {
                        transform: translateY(-4px) scale(1.02);
                        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3), 0 20px 25px -5px rgba(0,0,0,0.1);
                        border-color: var(--line-active);
                        z-index: 50;
                    }

                    /* Subordinate State */
                    .org-card.state-subordinate {
                        transform: translateY(-2px);
                        box-shadow: var(--shadow-md);
                        background-color: #fff;
                        border: 1px solid var(--line-active);
                    }

                    /* Ancestor State */
                    .org-card.state-ancestor {
                         box-shadow: var(--shadow-md);
                    }

                    /* Dimmed State */
                    .org-card.state-dimmed {
                        filter: grayscale(0.8) contrast(0.9);
                        transform: scale(0.98);
                    }

                    /* Disabled / On Vacation State */
                    .org-card.state-disabled {
                        filter: grayscale(0.4);
                        border: 1px dashed #ef4444 !important;
                        background-color: #fff !important;
                    }
                    .org-card.state-disabled .avatar {
                        filter: grayscale(1);
                        opacity: 0.8;
                    }

                    /* Highlight (Search Match) */
                    .org-card.highlight {
                        background-color: #fffbeb;
                        border: 1px solid #f59e0b;
                    }

                    /* Header Layout */
                    .card-header {
                        display: flex;
                        align-items: center;
                        gap: 14px;
                    }

                    .avatar {
                        width: 42px;
                        height: 42px;
                        border-radius: 50%; /* Circular for modern look */
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-weight: 700;
                        font-size: 1rem;
                        flex-shrink: 0;
                        box-shadow: inset 0 0 0 1px rgba(0,0,0,0.05);
                    }

                    .info {
                        flex: 1;
                        min-width: 0;
                    }

                    .name {
                        margin: 0;
                        font-size: 1rem;
                        font-weight: 700;
                        color: var(--text-primary);
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        letter-spacing: -0.015em;
                        line-height: 1.2;
                    }

                    .role {
                        margin: 3px 0 0 0;
                        font-size: 0.85rem;
                        color: var(--text-secondary);
                        font-weight: 500;
                        display: -webkit-box;
                        -webkit-line-clamp: 2;
                        -webkit-box-orient: vertical;
                        overflow: hidden;
                        line-height: 1.35;
                    }

                    /* Footer */
                    .card-footer {
                        padding-top: 4px;
                        display: flex;
                    }

                    .dept-badge {
                        font-size: 0.7rem;
                        font-weight: 600;
                        padding: 3px 10px;
                        border-radius: 6px;
                        border: 1px solid;
                        text-transform: uppercase;
                        letter-spacing: 0.04em;
                        max-width: 100%;
                        white-space: nowrap;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        background-color: transparent; /* Overridden inline */
                    }

                    /* Group Node */
                    .group-node {
                        height: 60px;
                        border: 1px dashed var(--line-color);
                        background: rgba(255,255,255,0.5);
                    }
                    .group-node:hover {
                        border-color: var(--line-active);
                        background: #fff;
                    }

                    /* Toggle Button */
                    .toggle-btn {
                        position: absolute;
                        bottom: -14px;
                        left: 50%;
                        transform: translateX(-50%);
                        width: 28px;
                        height: 28px;
                        background: #fff;
                        border: 1px solid var(--border-color);
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 0.8rem;
                        color: var(--text-secondary);
                        box-shadow: var(--shadow-sm);
                        transition: all 0.2s;
                        z-index: 5;
                    }
                    .toggle-btn:hover {
                        color: var(--text-primary);
                        border-color: var(--text-secondary);
                        transform: translateX(-50%) scale(1.1);
                    }
                    .toggle-btn.expanded .icon-chevron {
                        transform: rotate(180deg);
                        transition: transform 0.3s;
                    }

                    /* Loading / Error */
                    .loading-container, .error-container {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        height: 100vh;
                        color: var(--text-secondary);
                        gap: 16px;
                    }
                    .spinner {
                        color: var(--text-primary);
                        animation: spin 1s linear infinite;
                    }
                    @keyframes spin { to { transform: rotate(360deg); } }

                    /* Tooltip */
                    .node-tooltip {
                        position: fixed;
                        background: #fff;
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 16px;
                        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
                        z-index: 100;
                        pointer-events: auto; /* Allow clicking links */
                        width: max-content; /* Dynamic width */
                        max-width: 450px; /* Increased to accommodate long emails */
                        animation: fadeIn 0.2s ease-out;
                        color: var(--text-primary);
                    }
                    @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }

                    .tooltip-header {
                        font-weight: 600;
                        font-size: 0.9rem;
                        margin-bottom: 12px;
                        display: flex;
                        align-items: center;
                        gap: 4px;
                        color: #0f172a;
                    }

                    .tooltip-row {
                        display: flex;
                        align-items: center;
                        gap: 12px;
                        margin-bottom: 8px;
                        font-size: 0.9rem;
                    }
                    .tooltip-row:last-child { margin-bottom: 0; }

                    .icon-tooltip {
                        color: #64748b;
                        flex-shrink: 0;
                    }

                    .tooltip-link {
                        color: #2563eb; /* Blue-600 */
                        text-decoration: none;
                        white-space: normal; /* Allow wrapping if needed */
                        word-break: break-word; /* Break long emails */
                    }
                    .tooltip-link:hover {
                        text-decoration: underline;
                    }

                    .tooltip-text {
                        color: #334155; /* Slate-700 */
                        white-space: normal;
                        word-break: break-word;
                    }

                `}</style>
            </div>
        </OrganogramContext.Provider>
    );
};

export default OrganogramPage;
