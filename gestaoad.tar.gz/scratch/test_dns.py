import os
import json
import logging
import sys

# Insere o diretório base no path para importação
sys.path.insert(0, '/app')

print("--- FILE DIAGNOSTICS ---")
data_dir = "data"
print(f"data_dir exists: {os.path.exists(data_dir)}")

files = ["users.json", "config.json", "secret.key", "flask_secret.key"]
for f in files:
    path = os.path.join(data_dir, f)
    exists = os.path.exists(path)
    readable = os.access(path, os.R_OK) if exists else False
    writable = os.access(path, os.W_OK) if exists else False
    print(f"File {f}: exists={exists}, readable={readable}, writable={writable}")
    if exists and readable and f == "users.json":
        try:
            with open(path, 'r') as file:
                content = json.load(file)
                print(f"  users.json keys: {list(content.keys())}")
        except Exception as err:
            print(f"  Error reading users.json: {err}")

print("\n--- LDAP / AD CONNECTIVITY TEST ---")
try:
    from common import load_config, get_ldap_connection, get_user_by_samaccountname
    config = load_config()
    print(f"AD Domain: {config.get('AD_DOMAIN')}")
    print(f"AD Server: {config.get('AD_SERVER')}")
    print(f"Service Account: {config.get('SERVICE_ACCOUNT_USER')}")
    
    # Try connecting with service account
    conn = get_ldap_connection()
    print("SUCCESS: Bound successfully with Service Account!")
    
    # Try to search for 'welerMS'
    user = get_user_by_samaccountname(conn, "welerMS")
    if user:
        print("SUCCESS: Found user 'welerMS' in Active Directory!")
        print(f"  DN: {user.entry_dn}")
        print(f"  displayName: {user.displayName.value if 'displayName' in user else 'N/A'}")
    else:
        print("FAILED: User 'welerMS' NOT found in Active Directory!")
except Exception as err:
    print(f"LDAP ERROR: {err}")
