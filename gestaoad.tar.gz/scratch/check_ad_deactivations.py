
import os
import json
from datetime import datetime, timedelta, timezone
from ldap3 import Server, Connection, ALL, SUBTREE
from common import load_config, get_ldap_connection

def check_recent_deactivations():
    config = load_config()
    search_base = config.get('AD_SEARCH_BASE')
    conn = get_ldap_connection()
    
    # Filter for disabled users
    # (userAccountControl:1.2.840.113556.1.4.803:=2) is the bitwise filter for disabled
    # but we can also use a heuristic for whenChanged >= 7 days ago
    seven_days_ago = (datetime.now(timezone.utc) - timedelta(days=7)).strftime('%Y%m%d%H%M%S.0Z')
    
    search_filter = f"(&(objectClass=user)(objectCategory=person)(userAccountControl:1.2.840.113556.1.4.803:=2)(whenChanged>={seven_days_ago}))"
    
    print(f"Searching with filter: {search_filter}")
    conn.search(search_base, search_filter, attributes=['cn', 'sAMAccountName', 'whenChanged'])
    
    print(f"Found {len(conn.entries)} entries.")
    for entry in conn.entries:
        print(f"- {entry.cn}: {entry.whenChanged}")

if __name__ == "__main__":
    check_recent_deactivations()
