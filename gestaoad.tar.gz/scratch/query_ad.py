import common

conn = common.get_service_account_connection()
conn.search('DC=comolatti,DC=lan', '(cn=*admissao*)', attributes=['cn', 'groupType', 'mail', 'proxyAddresses'])
for entry in conn.entries:
    print("CN:", entry.cn.value)
    print("groupType:", entry.groupType.value if 'groupType' in entry else None)
    print("mail:", entry.mail.value if 'mail' in entry else None)
    print("proxyAddresses:", entry.proxyAddresses.values if 'proxyAddresses' in entry else None)
