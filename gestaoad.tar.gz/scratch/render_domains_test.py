from app import app
from flask import render_template

with app.test_request_context('/admin/zimbra_config'):
    try:
        # Simula as variaveis da view com dominios reais
        rendered = render_template(
            'admin/zimbra_config.html',
            zimbra_url="https://correio.comolatti.com.br:9071/service/admin/soap",
            zimbra_user="apipenso@comolatti.com.br",
            zimbra_enabled=True,
            mappings=[],
            domains=[{"name": "comolatti.com.br", "id": "dom-1"}, {"name": "pellegrino.com.br", "id": "dom-2"}],
            connection_ok=True
        )
        
        # Encontra a parte que contem theme-code-text
        lines = rendered.split('\n')
        print("[RENDER] Exibindo trechos contendo 'theme-code-text':")
        for i, line in enumerate(lines):
            if 'theme-code-text' in line:
                print(f"Linha {i}: {line.strip()}")
    except Exception as e:
        print("[RENDER] Erro ao renderizar:", e)
