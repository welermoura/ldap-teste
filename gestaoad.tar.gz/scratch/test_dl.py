import requests
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

# Desabilita avisos de certificados SSL autoassinados
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

USER = "apipenso@comolatti.com.br"
PASSWORD = "bY&!m3O3i4DRaw#"
URL = "https://correio.comolatti.com.br:9071/service/admin/soap"

def send_request(body_xml, token=None):
    headers = {
        "Content-Type": "application/soap+xml; charset=utf-8"
    }
    
    header_xml = ""
    if token:
        header_xml = f"""
        <context xmlns="urn:zimbra">
            <authToken>{escape(token)}</authToken>
        </context>
        """
        
    soap_envelope = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
        <soap:Header>
            {header_xml}
        </soap:Header>
        <soap:Body>
            {body_xml}
        </soap:Body>
    </soap:Envelope>
    """
    
    response = requests.post(URL, data=soap_envelope.encode('utf-8'), headers=headers, timeout=10, verify=False)
    return response

# 1. Autenticar
auth_xml = f"""
<AuthRequest xmlns="urn:zimbraAdmin">
    <name>{escape(USER)}</name>
    <password>{escape(PASSWORD)}</password>
</AuthRequest>
"""

print("[1] Autenticando...")
auth_resp = send_request(auth_xml)
print(f"Status Autenticação: {auth_resp.status_code}")
if auth_resp.status_code != 200:
    print("Corpo:", auth_resp.text)
    exit(1)

root = ET.fromstring(auth_resp.content)
body = root.find("{http://www.w3.org/2003/05/soap-envelope}Body")
auth_response = body.find("{urn:zimbraAdmin}AuthResponse")
token = auth_response.find("{urn:zimbraAdmin}authToken").text.strip()
print("[SUCCESS] Autenticado com sucesso!")

# 2. Tentar buscar a Lista de Distribuição
# Usaremos o e-mail que você mapeou na tela.
# Como o erro ocorreu no Sync, o e-mail mapeado provavelmente não existe ou tem formato incorreto.
# Vamos tentar buscar uma lista comum (ex: diretoria@comolatti.com.br) ou listar as DLs do sistema
dl_email = "diretoria@comolatti.com.br" # vamos tentar este primeiro ou o que estiver mapeado
print(f"\n[2] Buscando membros da DL: {dl_email}...")

dl_xml = f"""
<GetDistributionListRequest xmlns="urn:zimbraAdmin">
    <dl>{escape(dl_email)}</dl>
</GetDistributionListRequest>
"""

dl_resp = send_request(dl_xml, token)
print(f"Status HTTP: {dl_resp.status_code}")
print("Corpo da Resposta:")
print(dl_resp.text)
