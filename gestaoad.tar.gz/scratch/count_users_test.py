import sys
import os
sys.path.insert(0, os.path.abspath('.'))
from common import get_ad_connection, load_config
from ldap3 import SUBTREE

conn = get_ad_connection(read_only=True)
config = load_config()
search_base = config.get('AD_SEARCH_BASE')

queries = [
    '(objectClass=user)',
    '(&(objectClass=user)(objectCategory=person))',
    '(&(objectClass=user)(objectCategory=person)(userPrincipalName=*))',
    '(&(objectClass=user)(objectCategory=person)(sAMAccountName=*))'
]

for q in queries:
    count = 0
    gen = conn.extend.standard.paged_search(
        search_base=search_base,
        search_filter=q,
        attributes=['sAMAccountName'],
        paged_size=1000,
        generator=True
    )
    for _ in gen:
        count += 1
    print(f"Query: {q} -> Count: {count}")
